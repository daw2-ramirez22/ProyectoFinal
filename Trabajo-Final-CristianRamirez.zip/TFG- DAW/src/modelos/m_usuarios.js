const mongoose = require('mongoose')
const schema = mongoose.Schema

//Creaamos el esquema
const usuarioSchema = new mongoose.Schema({
    nombre:String,
    apellidos:String,
    email:String
})

//Creamos el modelo
const m_usuarios = mongoose.model('usuarios',usuarioSchema)

//exportamos
module.exports = m_usuarios