const mongoose = require('mongoose')
const schema = mongoose.Schema

//Creaamos el esquema
const productoSchema = new mongoose.Schema({
    categoria:String,
    nombre:String,
    precio:String
})

//Creamos el modelo
const m_productos = mongoose.model('producto',productoSchema)

//exportamos
module.exports = m_productos