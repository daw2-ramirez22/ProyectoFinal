const express = require('express')
//requiero la funcion de leer usuarios de el controlador
const { leerUsuarios, leerUsuarioId, CrearUsuario, EditarUsuarioId, BorrarUsuariosId } = require('../controladores/c_usuarios')
const r_usuarios = express.Router()

//rutas get
r_usuarios.get('/', leerUsuarios)
r_usuarios.get('/:id', leerUsuarioId)

//rutas post
r_usuarios.post('/', CrearUsuario)

//rutas put
r_usuarios.put('/:id', EditarUsuarioId)

//rutas delete
r_usuarios.delete('/:id', BorrarUsuariosId)

module.exports = r_usuarios