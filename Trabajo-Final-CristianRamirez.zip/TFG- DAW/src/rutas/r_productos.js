const express = require('express')
//requiero la funcion de leer usuarios de el controlador
const { leerProductos, leerProductoId, CrearProducto, EditarProductoId, BorrarProductosId } = require('../controladores/c_productos')
const r_productos = express.Router()

//rutas get
r_productos.get('/', leerProductos)
r_productos.get('/:id', leerProductoId)

//rutas post
r_productos.post('/', CrearProducto)

//rutas put
r_productos.put('/:id', EditarProductoId)

//rutas delete
r_productos.delete('/:id', BorrarProductosId)

module.exports = r_productos