const m_productos = require("../modelos/m_productos")


module.exports =  {
    leerProductos : async (req,res) => {
        //leer usuarios de la base de datos Usuarios
        try {
            const productosEncontrados = await m_productos.find()
            res.json(productosEncontrados)
        } catch (error) {
            res.json({
                error: error,
                mensaje : 'Ohh, algo ha fallado en la peticion a la coleccion usuarios de la base de datos' + error
            })
        }
    },
    leerProductoId : async (req,res) => {
          //leer usuarios de la base de datos Usuario con ID
        try {
            const id = req.params.id
            const productosEncontrado = await m_productos.findById(id)
            res.json(productosEncontrado)
        } catch (error) {
            res.json({
                error: error,
                mensaje : 'Ohh, algo ha fallado en la peticion a la coleccion usuarios de la base de datos' + error
            })
        }

    },
    CrearProducto : async(req,res) => {
        const producto = new m_productos({
            categoria: req.body.categoria,
            nombre: req.body.nombre,
            precio: req.body.precio
        })
        try {
            const productoGuardado = await producto.save()
            res.json(productoGuardado)
        } catch (error) {
            res.json({
                error: error,
                mensaje : 'Ohh, Escribiendo el usuario en la BD' + error
            })
        }
    },
    EditarProductoId : async (req,res) => {
        //editar elemento de una base de datos
        try {
            const id = req.params.id
            const producto = {
                categoria: req.body.categoria,
                nombre: req.body.nombre,
                precio: req.body.precio
                
            }
            const productosEncontrado = await m_productos.findByIdAndUpdate(id,producto)
            res.json(productosEncontrado)
        } catch (error) {
            res.json({
                error: error,
                mensaje : 'Ohh, algo ha fallado en la peticion a la coleccion usuarios de la base de datos' + error
            })
        }

    },
    BorrarProductosId : async (req,res) => {
        try {
            const id = req.params.id
            const productosEncontrado = await m_productos.findByIdAndDelete(id)
            res.json(productosEncontrado)
        } catch (error) {
            res.json({
                error: error,
                mensaje : 'Ohh, algo ha fallado en la peticion a la coleccion usuarios de la base de datos' + error
            })
        }
    }
}