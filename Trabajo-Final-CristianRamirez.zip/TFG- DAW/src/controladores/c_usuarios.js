const m_usuarios = require("../modelos/m_usuarios")


module.exports =  {
    leerUsuarios : async (req,res) => {
        //leer usuarios de la base de datos Usuarios
        try {
            const usuariosEncontrados = await m_usuarios.find()
            res.json(usuariosEncontrados)
        } catch (error) {
            res.json({
                error: error,
                mensaje : 'Ohh, algo ha fallado en la peticion a la coleccion usuarios de la base de datos' + error
            })
        }
    },
    leerUsuarioId : async (req,res) => {
          //leer usuarios de la base de datos Usuario con ID
        try {
            const id = req.params.id
            const usuariosEncontrado = await m_usuarios.findById(id)
            res.json(usuariosEncontrado)
        } catch (error) {
            res.json({
                error: error,
                mensaje : 'Ohh, algo ha fallado en la peticion a la coleccion usuarios de la base de datos' + error
            })
        }

    },
    CrearUsuario : async(req,res) => {
        const usuario = new m_usuarios({
            nombre: req.body.nombre,
            apellidos: req.body.apellidos,
            email: req.body.email
        })
        try {
            const usuarioGuardado = await usuario.save()
            res.json(usuarioGuardado)
        } catch (error) {
            res.json({
                error: error,
                mensaje : 'Ohh, Escribiendo el usuario en la BD' + error
            })
        }
    },
    EditarUsuarioId : async (req,res) => {
        //editar elemento de una base de datos
        try {
            const id = req.params.id
            const usuario = {
                nombre: req.body.nombre,
                apellidos: req.body.apellidos,
                email: req.body.email
            }
            const usuariosEncontrado = await m_usuarios.findByIdAndUpdate(id,usuario)
            res.json(usuariosEncontrado)
        } catch (error) {
            res.json({
                error: error,
                mensaje : 'Ohh, algo ha fallado en la peticion a la coleccion usuarios de la base de datos' + error
            })
        }

    },
    BorrarUsuariosId : async (req,res) => {
        try {
            const id = req.params.id
            const usuariosEncontrado = await m_usuarios.findByIdAndDelete(id)
            res.json(usuariosEncontrado)
        } catch (error) {
            res.json({
                error: error,
                mensaje : 'Ohh, algo ha fallado en la peticion a la coleccion usuarios de la base de datos' + error
            })
        }
    }
}