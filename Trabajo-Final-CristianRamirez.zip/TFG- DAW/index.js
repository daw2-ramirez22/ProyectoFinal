// requerimos express la va a buscar a node_modules
const express = require('express')
const morgan = require('morgan')
const r_usuarios = require('./src/rutas/r_usuarios')
const r_productos = require('./src/rutas/r_productos')

const db = require ('./database.js')

//Verificamos conexion a base de datos
db.on('error', (error) =>{
    console.log('Se ha producido un error al conectar' + error)
})
db.on('connected', () =>{
    console.log('La db se conecto de muerte')
})

// Aplicacion del servidor
const app = express()

//Middelware
app.use(express.json()) // esto es para parsear las peticiones
app.use(express.urlencoded({extended: true})) // parsear datos en las peticiones
app.use(morgan('combined'))

app.use('/usuarios', r_usuarios)
app.use('/productos', r_productos)

app.get('/', (req, res)=> {
    res.send('Estas en la raiz de tu servidor NODE')
})

app.listen(8080, ()=> {
    console.log('El servidor esta escuchando')
})