//mongodb+srv://ramirezsanchezcristian:3fGPYris4nJ1aNCC@cluster-tfm.n601a9n.mongodb.net/?retryWrites=true&w=majority

const mongoose = require('mongoose')

const DB_USER = 'ramirezsanchezcristian'
const DB_NAME = 'DB_TFG_DAW'
const DB_PASS = '3fGPYris4nJ1aNCC'

const uri = `mongodb+srv://${DB_USER}:${DB_PASS}@cluster-tfm.n601a9n.mongodb.net/${DB_NAME}?retryWrites=true&w=majority`

mongoose.connect(uri, {useNewUrlParser : true, useUnifiedTopology: true})

const db = mongoose.connection

module.exports = db 
